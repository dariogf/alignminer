#!/usr/bin/perl -w
### param1 param2


# Dario Guerrero
# =======================
# v0.1  -  18-02-2007


=head1 NAME

alignMiner - Algoritmo de detección de información en alineamientos

=head1 REQUISITES

    -Log::Log4perl : cpan> install -f Log::Log4perl
    -Bioperl
    -gnuplot (necesita libgd para png)
    -Template: cpan> install Template
    -JSON: cpan> install JSON
     http://sourceforge.net/project/showfiles.php?group_id=2888&package_id=237839&release_id=563686
    ### poner esto en bash_profile si no anda el aquaterm: export GNUTERM=X11
    -Math:FFT

=head1 SYNOPSIS


=head1 DESCRIPTION


=head1 AUTHOR - Diego Darío Guerrero Fernández

Email dariogf@scbi.uma.es

=head1 APPENDIX

El resto de la documentacion es una descripcion de los metodos implementados.

Los metodos internos y privados comienzan con "_".

=cut

use strict;
use File::Basename;

# cambiar esto para despliegue
# use lib '/Volumes/Documentos/Progs/bio/AlignMiner';
use lib '/usr/local/alignminer';

# librerias bio
use Bio::AlignIO;
# use Bio::Align::AlignI;


# para permitir loggin
use Log::Log4perl qw(:easy);

use File::Path;

use Utils::Printing qw(:All);

use AM::TAlignSetAM;

use AM::TCountAM;

use alignminer_h qw(:All);



# ====================================================
# ===================== CONSTANTES ===================
# ====================================================

# ====================================================
# =============== PROTIPOS FUNCIONES =================
# ====================================================

# ====================================================
# ====================== MAIN ========================
# ====================================================

# ASK-DONE -Ver mean vs median en MAD
# ASK-DONE -En Tabla frecuencias para f3:
# TODO-DONE -Calcular los SNP
# TODO -Interfaz web/AJAX
# TODO -Resultados regiones ordenados por SCORE

# ASK -¿Como es posible que en una gráfica de similitud f1 existan trozos positivos (eg alineamientoclustal)? Si todas las bases fuesen iguales, el valor debería ser 0, y negativo si hay diferencias.

# ASK -Pedir alineamientos que ya hayan sido estudiados a mano y se hayan extraído los SNP y regiones para poder hacer pruebas.

# SHOW -Mostrar SNPs
# SHOW -Mostrar web
# SHOW -Mostrar exportación JSON para AJAX

# SHOW -EJS char - http://www.ejschart.com/

# recibe los parametros
my $inputfilename="";

# $inputfilename = "/Volumes/Docum	entos/Progs/bio/AlignMiner/alignments/adn";

# $inputfilename = "alignments/gogat";

# alineamiento 500.000
# $inputfilename = "alignments2/larguisimo.msf";
# $inputfilename = "alignments2/medio.msf";

# dna buena grafica f3
# $inputfilename = "alignments2/alineamientoClustal.msf"; 

# alineamiento rarisimo
# $inputfilename = "alignments2/alineamientoMauve.aln"; 

# alineamiento rarisimo
# $inputfilename = "alignments2/patatas_ClustalW.msf"; 

if ($inputfilename eq "") {
    my $argc = $#ARGV+1;
    
    # si no hay parametros mostrar info
    if (!$argc == 2) {
        print("Usage: \n#>".basename($0)." filename ID\n\n");
        exit;
    }
    
    $inputfilename=$ARGV[0];

    # run ID viene del padre
    $RUNID = $ARGV[1];
}
# 
# # obtener un numero unico para identificar el proceso
# my $time = time; 
# 
# # identificador unico de la ejecucion con el tiempo y el pid de la ejecución actual
# $RUNID = $time . $$;


# print "Run ID : $runId";

$OUTPUT_DIR = "$BASE_OUTPUT_DIR$RUNID/";

$GRAPH_OUTPUT_DIR = $OUTPUT_DIR.'graphs/';
$DATA_OUTPUT_DIR = $OUTPUT_DIR.'data/';
$JSON_OUTPUT_DIR = $OUTPUT_DIR.'json/';
$MATLAB_OUTPUT_DIR = $OUTPUT_DIR.'matlab/';


mkpath([$GRAPH_OUTPUT_DIR,
$JSON_OUTPUT_DIR,
$DATA_OUTPUT_DIR,
$MATLAB_OUTPUT_DIR]);

# Establece un logger
my $logger = setupLogging($OUTPUT_DIR.'log.txt');
$logger->info("Starting execution $RUNID");

# nuevo objeto de alineamientos
my $alignSetAM = AM::TAlignSetAM->new($inputfilename);

my $procesedAlignments = 0;

# para cada alinemamiento
while ( my $alignAM = $alignSetAM->next_aln()) {

  $procesedAlignments++;
  $logger->info("Processing alignment #".$procesedAlignments);

  # procesar el alineamiento
  $alignAM->process();
  
}

$logger->info("The END.");


# ====================================================
# ====================== SUBS ========================
# ====================================================

# ===================================================
# Activa el loggin
# ===================================================
sub setupLogging {
    # Solo a pantalla
    # Log::Log4perl->easy_init($DEBUG);
    my ($fn) = @_;
    
    # A fichero
    Log::Log4perl->easy_init( { level   => $DEBUG,
                                file    => ">>$fn" } );

    # Configuracion avanzada de logging

    # my $conf = q(
    #     log4perl.logger                    = ERROR, FileApp
    #     log4perl.appender.FileApp          = Log::Log4perl::Appender::File
    #     log4perl.appender.FileApp.filename = 'file.log'
    #     log4perl.appender.FileApp.layout   = PatternLayout
    #     log4perl.appender.FileApp.layout.ConversionPattern = %d> %m%n
    # );
    
    # Log::Log4perl->init( \$conf );

    return get_logger();

}

