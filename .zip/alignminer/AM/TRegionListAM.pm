# Dario Guerrero
# =======================
# v0.1  -  2008


=head1 NAME

TRegionListAM - Mantiene una lista de regiones de una grafica que cumplen un requisito 

=head1 SYNOPSIS

    use AM::TRegionListAM;

    # creando el objeto
    my $obj = AM::TRegionListAM->new();
    

=head1 DESCRIPTION

La clase AM::TRegionListAM Mantiene una lista de regiones de una grafica que cumplen un requisito

=head1 AUTHOR - Diego Darío Guerrero Fernández

Email dariogf@scbi.uma.es

=head1 APPENDIX

El resto de la documentacion es una descripcion de los metodos implementados.

Los metodos/propiedades internos y privados comienzan con "_".

=cut

package AM::TRegionListAM;

use strict;

use Log::Log4perl qw(get_logger);

use base qw(AM::TAMObject);

# use AM::TAlignAM;

use Utils::Printing qw(:All);

use JSON;

use alignminer_h qw(:All);

#-----------------------------------------------------------------------------#

=head2 new

 Title   : newRegion
 Usage   : $var=TRegionListAM->new($description,$operation,$limit,$alignAM,$isSNP,@a);
           my $regionList = AM::TRegionListAM->new(sub {$_[0]<=$_[1]},$limit,@a);

 Function: Constructor del objeto.

 Returns : TRegionListAM Object
 Args    : $operation -> referencia a una función de comparación

=cut

#-----------------------------------------------------------------------------#
sub new {
        my $class = shift;
        # print "init class : \n";
        my ($description,$operation,$limit,$alignAM,$isSNP,@a) = @_;
        
        # inicializa con el padre
        my $self = $class->SUPER::new(@_);
        
        # # hash vacio para alojar el objeto
        # my $self  = {};
        
        my @regs=();
        $self->{_description}=$description;
        $self->{_operation}= $operation;
        $self->{_limit}=$limit;
        $self->{_alignAM} = $alignAM;
        $self->{_regionList} = \@regs;
        
        # cambia el tipo del hash por el de la clase
        bless ($self, $class);
        
        if ($isSNP) {
            $self->_filterSNP(@a);
        }
        else{
            $self->_filterRegions(@a);
        }
        
        return $self;
}

#-----------------------------------------------------------------------------#

=head2 DESTROY

 Title   : DESTROY
 Usage   : Llamado automáticamente.
 
 Function: Destructor del objeto.

 Returns : 
 Args    : 

=cut

#-----------------------------------------------------------------------------#
sub DESTROY {
    my $self = shift;
    
}

##############################################
##        Property Access Methods           ##
##############################################

#-----------------------------------------------------------------------------#

=head2 description

    Used to set or get the value of description

=cut

#-----------------------------------------------------------------------------#
sub description {
   my $self = shift;
   
   my ( $param ) = @_; 
   $self->{_description} = $param if defined($param);

   return $self->{_description};
}


#-----------------------------------------------------------------------------#

=head2 limit

    Used to set or get the value of limit

=cut

#-----------------------------------------------------------------------------#
sub limit {
   my $self = shift;
   
   my ( $param ) = @_; 
   $self->{_limit} = $param if defined($param);

   return $self->{_limit};
}


#-----------------------------------------------------------------------------#

=head2 operation

    Used to set or get the value of operation

=cut

#-----------------------------------------------------------------------------#
sub operation {
   my $self = shift;
   
   my ( $param ) = @_; 
   $self->{_operation} = $param if defined($param);

   return $self->{_operation};
}


#-----------------------------------------------------------------------------#

=head2 regionList

    Used to set or get the value of regionList

=cut

#-----------------------------------------------------------------------------#
sub regionList {
   my $self = shift;
   
   my ( $param ) = @_; 
   $self->{_regionList} = $param if defined($param);

   return @{$self->{_regionList}};
}


#-----------------------------------------------------------------------------#

=head2 alignAM

    Used to set or get the value of alignAM

=cut

#-----------------------------------------------------------------------------#
sub alignAM {
   my $self = shift;
   
   my ( $param ) = @_; 
   $self->{_alignAM} = $param if defined($param);

   return $self->{_alignAM};
}


##############################################
##                 Functions                ##
##############################################

#-----------------------------------------------------------------------------#

=head2 saveJSON

 Title   : saveJSON
 Usage   : $graph->saveJSON($filename,$structref);
 
 Function: Guarda la gráfica en formato JSON

 Returns : 
 Args    : 

=cut

#-----------------------------------------------------------------------------#
sub saveJSON {
    my $self = shift;

    (my $file,my $a) = @_;
    
    # print "save JSON:$a\n";
        
    open (FILE, ">$file");
    
    my $json_text = to_json($a);
    
    print FILE $json_text;
    
    close(FILE);
    
}#saveJSON


#-----------------------------------------------------------------------------#

=head2 _filterRegions

 Title   : _filterRegions
 Usage   : $regionList->_filterRegions();
 
 Function: Filtra las regiones con los datos indicados

 Returns : 
 Args    : 

=cut

#-----------------------------------------------------------------------------#
sub _filterRegions {
    my $self = shift;
    # (my $) = @_;
    my @a = @_;
    
    my $logger = get_logger();
    
    my @res;
    my $i=0;
    
    my $limit = $self->limit;
    
    my $phase = '';
    my $start;
    my $end;
    my $score;
    
    my $compareFunc = $self->operation;
    
    $logger->info("Filtering regions ".$self->description." limit: $limit ===  ".$self->description." ===");
    
    foreach my $e (@a) {
        
        if ($phase eq '') {
            if (&$compareFunc($e,$limit)) {
                # comienza anotacion
                $start=$i;
                $score=$e;
                
                $phase='anotating';
            }
            
        }elsif ($phase eq 'anotating') {
            # if ($e<=$limit) {
            if (&$compareFunc($e,$limit)) {
                
                # sigue anotacion
                $score+=$e;
                # $phase='anotating';
            }else{
                $end=$i-1;
                $self->addRegion($start,$end,$score/($end-$start+1));
                # fin anotacion
                $phase='';
            }
            
        }
        
        $i++;
    }
    
    my @rl = $self->regionList;
    $self->saveJSON("$JSON_OUTPUT_DIR".$self->description.".json",\@rl);
    # printArray('rl'.$self->description,@rl);    
}#_filterRegions

#-----------------------------------------------------------------------------#

=head2 _filterSNP

 Title   : _filterSNP
 Usage   : $self->_filterSNP();
 
 Function: Filtra los SNP

 Returns : Lista SNP
 Args    : 

=cut

#-----------------------------------------------------------------------------#
sub _filterSNP {
    my $self = shift;

    my @a = @_;
    
    my $logger = get_logger();
    
    my @res;
    my $i=0;
    
    my $limit = $self->limit;
    
    my $phase = '';
    my $start;
    my $end;
    my $score;
    
    my $compareFunc = $self->operation;
    
    my $alignAM = $self->alignAM;
    my $countAM = $alignAM->countAM;
    
    my @consensus = $alignAM->consensus;
    
    $logger->info("Filtering SNP ".$self->description." limit: $limit ===  ".$self->description." ===");
    
    foreach my $e (@a) {
        
        if ($phase eq '') {
            if (&$compareFunc($e,$limit)) {
                # comienza anotacion
                $start=$i;
                $score=$e;
                
                $phase='anotating';
            }
            
        }elsif ($phase eq 'anotating') {
            # if ($e<=$limit) {
            if (&$compareFunc($e,$limit)) {
                
                # sigue anotacion
                $score+=$e;
                # $phase='anotating';
            }else{
                $end=$i-1;
                
                # Si el ancho es 1
                if ($start == $end ){
                    
                    # ASK -Cómo se sabe qué letra genera el pico de la gráfica
                    # ahora mismo miro que la base mayoritaria no aparezca en al menos 2 secuencias,
                    # y además este SNP aparece 2 o más veces en COUNT
                    # $logger->info("SNP: start:$start, end:$end, consensus: ".$consensus[$start].", count:".$countAM->value($consensus[$start],$start));
                    
                    # recordar que deben ser más de 4 secuencias para dar resultados coherentes
                    
                    if (($countAM->value($consensus[$start],$start)) <= ($alignAM->numOfSequences()-2)) {
                        # $logger->info("SNP: start:$start, end:$end, consensus: ".$consensus[$start].", count:".$countAM->value($consensus[$start],$start));
                        
                        $self->addRegion($start,$end,$score/($end-$start+1));
                    }
                }
                # fin anotacion
                $phase='';
            }
            
        }
        
        $i++;
    }
    
    my @rl = $self->regionList;
    $self->saveJSON("$JSON_OUTPUT_DIR".$self->description.".json",\@rl);
    # printArray('rl'.$self->description,@rl);

}#_filterSNP


#-----------------------------------------------------------------------------#

=head2 addRegion

 Title   : addRegion
 Usage   : $regionList->addRegion($start,$end,$score);
 
 Function: Añade una región a la lista

 Returns : 
 Args    : $start, $end, $score

=cut

#-----------------------------------------------------------------------------#
sub addRegion {
    my $self = shift;
    my ($start,$end,$score) = @_;
    my %elem;
    
    my $logger=get_logger();
    
    my @a=$self->regionList;
    
    $elem{'startPos'}=$start;
    $elem{'endPos'}=$end;
    $elem{'score'}=$score;
    
    # $logger->info("Added [$start,$end](".($end-$start+1).")=$score");
    
    push(@a,\%elem);
    
    $self->regionList(\@a);
    
}#addRegion

1;  # so the require or use succeeds
