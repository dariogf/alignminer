//=======================================
//Clase para gestionar un canvas mejorado
//
// v0.1 - 20080426 - Diego Darío Guerrero
//=======================================

var TChartCanvas = Class.create({

  //Constructor
  initialize: function(canvas) {
    this.canvas =canvas;
    
  },

});
